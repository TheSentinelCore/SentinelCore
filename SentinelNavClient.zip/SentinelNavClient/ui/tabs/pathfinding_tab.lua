--[[
    Pathfinding Tab - String-pull tuning, optimization, terrain costs, indoor, wall clearance
]]

local Defaults = require("core/Defaults")

local PathfindingTab = {}

---Register the pathfinding tab with the UI
---@param ui any RotationSettingsUI instance
---@param menu table Menu elements table
function PathfindingTab.register(ui, menu)
    local M = Defaults.movement

    local function corridor_on()
        return menu.corridor:get_state()
    end

    local function wall_clearance_on()
        return menu.wall_clearance_en:get_state()
    end

    local function show_advanced()
        return menu.show_advanced:get_state()
    end

    ui:add_tab({ id = "pathfinding", label = "Pathfinding" }, function(t)
        -- Optimization
        t:checkbox_grid({
            label = "Optimization",
            columns = 1,
            elements = {
                { element = menu.optimize, label = "String-Pulling", tooltip = "Removes unnecessary waypoints by testing line-of-sight" },
                { element = menu.allow_partial, label = "Allow Partial Paths", tooltip = "Accept incomplete paths when a full path is unavailable" },
            }
        })

        -- String-Pull Tuning (advanced)
        t:slider_list({
            label = "String-Pull Tuning",
            visible_when = show_advanced,
            elements = {
                { element = menu.sp_deviation, label = "Max Deviation", min = M.string_pull_deviation.min, max = M.string_pull_deviation.max, suffix = " yd", tooltip = "Max 3D deviation for string-pull optimization (lower = tighter corners)" },
                { element = menu.sp_heading, label = "Max Heading Change", min = M.string_pull_heading.min, max = M.string_pull_heading.max, suffix = "\xC2\xB0", tooltip = "Max heading change in degrees (lower = preserves more curves)" },
                { element = menu.sp_wall_dist, label = "Min Wall Distance", min = M.string_pull_wall_dist.min, max = M.string_pull_wall_dist.max, suffix = " yd", tooltip = "Min wall distance for shortcuts (higher = tighter corners, 0 = disabled)" },
                { element = menu.densify_seg, label = "Segment Length", min = M.densify_segment_length.min, max = M.densify_segment_length.max, suffix = " yd", tooltip = "Max distance between waypoints (lower = smoother curves)" },
            }
        })

        -- Wall Clearance
        t:checkbox_grid({
            label = "Wall Clearance",
            columns = 1,
            elements = {
                { element = menu.wall_clearance_en, label = "Enable", tooltip = "Pushes path away from walls by the specified distance" },
            }
        })

        t:slider_list({
            visible_when = wall_clearance_on,
            elements = {
                { element = menu.wall_clearance, label = "Distance", min = M.wall_clearance.min, max = M.wall_clearance.max, suffix = " yd", tooltip = "Minimum distance to maintain from walls" },
            }
        })

        -- Indoor Navigation (always visible)
        t:checkbox_grid({
            label = "Indoor Navigation",
            columns = 1,
            elements = {
                { element = menu.corridor, label = "Corridor Pathfinding", tooltip = "Uses tighter pathfinding for indoor and corridor areas" },
            }
        })

        t:slider_list({
            visible_when = function() return corridor_on() and show_advanced() end,
            elements = {
                { element = menu.corridor_probe, label = "Probe Distance", min = M.corridor_probe_dist.min, max = M.corridor_probe_dist.max, suffix = " yd", tooltip = "How far ahead to probe for corridor detection" },
            }
        })

        -- Terrain Costs (advanced)
        t:slider_list({
            label = "Terrain Costs",
            visible_when = show_advanced,
            elements = {
                { element = menu.filter_ground, label = "Ground", min = M.filter_ground.min, max = M.filter_ground.max, tooltip = "Pathfinding cost multiplier for ground terrain" },
                { element = menu.filter_water, label = "Water", min = M.filter_water.min, max = M.filter_water.max, tooltip = "Pathfinding cost multiplier \xe2\x80\x94 higher values avoid water" },
                { element = menu.filter_lava, label = "Lava", min = M.filter_lava.min, max = M.filter_lava.max, tooltip = "Pathfinding cost multiplier \xe2\x80\x94 higher values avoid lava" },
            }
        })

    end)
end

return PathfindingTab
